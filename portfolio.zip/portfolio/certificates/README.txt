Put your certificate images here (JPG, PNG or WebP), for example:
  freelance-society.jpg
Then open index.html, find the CERTIFICATES block and set
  image: "certificates/freelance-society.jpg"
