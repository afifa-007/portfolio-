# Afifa Javed - Portfolio

Static website (no build step). Files:

- `index.html`  the whole site
- `certificates/`  put certificate images here
- `resume.pdf`  add your resume here (optional), then set `resume: "resume.pdf"` in the CONFIG block of index.html
- `.nojekyll`  tells GitHub Pages to serve the files as they are

## Publish on GitHub Pages (free)
1. Create a repository named `yourusername.github.io` (public).
2. Upload everything from this folder to the repository root (index.html must be at the root).
3. Repository Settings > Pages > Deploy from branch > `main` / root.
4. Your site goes live at `https://yourusername.github.io` in a minute or two.

## Edit your details
Open `index.html` and search for `CONFIG`: email, phone, LinkedIn, GitHub, resume and a Web3Forms key live there.
Projects are in the `PROJECTS` block and certificates in the `CERTIFICATES` block.
